<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
'title'
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
'title'
]); ?>
<?php foreach (array_filter(([
'title'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    header('X-Frame-Options: sameorigin');
    header('X-Content-Type-Options: nosniff');
    header('X-XSS-Protection: 1;mode=block');
    //header('Content-Security-Policy: default-src \'self\' \'unsafe-inline\' \'unsafe-eval\'; img-src \'self\' data:; style-src \'self\' \'unsafe-inline\'; script-src \'self\' \'unsafe-inline\' *.google.com www.gstatic.com; frame-src *.google.com gstatic.com');
    header('Permissions-Policy: camera=(), display-capture=(), geolocation=(), microphone=()');
    header('Referrer-Policy: origin-when-cross-origin');
    header('Strict-Transport-Security: max-age=31536000');

?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?php echo e($title); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('icons/512x512.png')); ?>"/>
    <meta id="_csrf_token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="HandheldFriendly" content="true">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <?php echo app('Illuminate\Foundation\Vite')([
    'resources/css/app.css',
    'resources/css/styles.css',
    ]); ?>
<body>
<?php echo e($slot); ?>

<?php echo app('Illuminate\Foundation\Vite')([
'resources/js/app.js',
]); ?>
</body>
</html>
<?php /**PATH C:\Alex\OpenServer\domains\laravel.start\resources\views/components/layouts/main.blade.php ENDPATH**/ ?>